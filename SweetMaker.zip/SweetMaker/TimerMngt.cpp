/*******************************************************************************
TimerMngt.cpp

Copyright(C) 2015-2016  Howard James May

This file is part of the SweetMaker SDK

The SweetMaker SDK is free software: you can redistribute it and / or
modify it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

The SweetMaker SDK is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.If not, see <http://www.gnu.org/licenses/>.

Contact me at sweet.maker@outlook.com
********************************************************************************
Release     Date                        Change Description
--------|-------------|--------------------------------------------------------|
  1      24-Feb-2016   Initial release
*******************************************************************************/

#include "TimerMngt.h"

using namespace SweetMaker;

#ifndef NULL
#define NULL 0
#endif

TimerMngt * TimerMngt::getTimerMngt()
{
	static TimerMngt * instance = NULL;
	if (instance == NULL)
		instance = new TimerMngt();
	return instance;
}

TimerMngt::TimerMngt()
{
	eventHandlerFunction = 0;
	eventHandlerObject = 0;
	eventSourceRef = 0;
	
	time_counter_ms = 0;
	time_counter_100ms = 0;
	time_counter_1s = 0;

	this->freqGenActiveListHead = NULL;
	this->timerActiveListHead = NULL;
}

void TimerMngt::configEventHandler(IEventHandler::EventHandler handler, uint8_t _eventSourceRef)
{
	eventHandlerFunction = handler;
	eventSourceRef = _eventSourceRef;
}

void TimerMngt::configEventHandler(IEventHandler * handlerObject, uint8_t _eventSourceRef)
{
	eventHandlerObject = handlerObject;
	eventSourceRef = _eventSourceRef;
}

void TimerMngt::update(uint16_t elapsedTime_ms)
{
	FreqGen * freqIter;
	Timer * timerIter;
	time_counter_ms += elapsedTime_ms;

	notifyHandlersOfEvent(TIMER_TICK_UPDATE, elapsedTime_ms);
	while(time_counter_ms >= 100)
	{
		notifyHandlersOfEvent(TIMER_TICK_100MS, 0);

		time_counter_ms -= 100;
		time_counter_100ms++;
		
		if(time_counter_100ms == 10)
		{
			notifyHandlersOfEvent(TIMER_TICK_S, 0);
			time_counter_100ms = 0;
			time_counter_1s++;

			if(time_counter_1s == 10)
			{
				notifyHandlersOfEvent(TIMER_TICK_10S, 0);
				time_counter_1s = 0;
			}
		}
	}

	freqIter = this->freqGenActiveListHead;
	while(freqIter != NULL)
	{
		uint32_t expectedEventCount_m;
		freqIter->countPeriod_ms += elapsedTime_ms;
		expectedEventCount_m = (uint32_t)freqIter->frequency_Hz * (uint32_t)freqIter->countPeriod_ms;

		while ((uint32_t)((uint32_t)(freqIter->eventCount + 1) * (uint32_t)1000) <= expectedEventCount_m)
		{
			freqIter->eventCount++;
			notifyHandlersOfEvent(TIMER_FREQ_GEN, 0);
		}

		if ((expectedEventCount_m >= 4000000000) || (freqIter->countPeriod_ms >= 60000) || (freqIter->eventCount >= 4000))
		{
			uint32_t usedTime_ms = (uint32_t)((freqIter->eventCount -1 )* (uint32_t)1000 ) / freqIter->frequency_Hz;
			freqIter->countPeriod_ms -= usedTime_ms;
			freqIter->eventCount = 1;
		}

		freqIter = freqIter->nextFreqGen;
	}

	timerIter = this->timerActiveListHead;
	while (timerIter != NULL)
	{
		if (elapsedTime_ms >= timerIter->countDown_ms)
		{
			Timer * nextTimer = timerIter->nextTimer;
			timerIter->countDown_ms = 0;
			notifyHandlersOfEvent(TIMER_EXPIRED, timerIter->eventInfo);
			timerIter->stopTimer();
			timerIter = nextTimer;
		}
		else
		{
			timerIter->countDown_ms -= elapsedTime_ms;
			timerIter = timerIter->nextTimer;
		}
	}
}

FreqGen::FreqGen()
{
	initialise();
}

FreqGen::FreqGen(uint16_t freq_hz, uint16_t ref)
{
	initialise();
	startFreqGen(freq_hz, ref);
}

void FreqGen::initialise()
{
	countPeriod_ms = 0;
	eventCount = 0;
	frequency_Hz = 0;
	ref = 0xffff;
	nextFreqGen = NULL;
}

int FreqGen::startFreqGen(uint16_t freq_hz, uint16_t ref)
{
	/* Need to protect against double addition */
	return 0;
	this->countPeriod_ms = 0;
	this->eventCount = 0;
	this->frequency_Hz = freq_hz;
	this->ref = ref;

	TimerMngt * tm = TimerMngt::getTimerMngt();
	this->nextFreqGen = tm->freqGenActiveListHead;
	tm->freqGenActiveListHead = this;

	return 0;
}

int FreqGen::stopFreqGen(void)
{
	TimerMngt * tm = TimerMngt::getTimerMngt();
	FreqGen * iter = tm->freqGenActiveListHead;

	if (iter == this)
	{
		tm->freqGenActiveListHead = iter->nextFreqGen;
		this->nextFreqGen = NULL;
		return 0;
	}

	while (iter->nextFreqGen != NULL)
	{
		if (iter->nextFreqGen == this)
		{
			iter->nextFreqGen = this->nextFreqGen;
			return 0;
		}
		iter = iter->nextFreqGen;
	}

	return -1;
}

void TimerMngt::notifyHandlersOfEvent(uint16_t eventId, uint16_t eventInfo)
{
	if(eventHandlerFunction)
		eventHandlerFunction(eventId, eventSourceRef, eventInfo);

	if(eventHandlerObject)
		eventHandlerObject->handleEvent(eventId, eventSourceRef, eventInfo);
}

Timer::Timer()
{
	initialise();
}

Timer::Timer(uint16_t duration_ms, uint16_t ref)
{
	initialise();
	startTimer(duration_ms, ref);
}

void Timer::initialise()
{
	countDown_ms = 0;
	eventInfo = 0xffff;
	nextTimer = NULL;
}

int Timer::startTimer(uint16_t duration, uint16_t ref)
{
	bool isActive = this->isRunning();

	this->countDown_ms = duration;
	this->eventInfo = ref;

	if (!isActive)
	{
		TimerMngt * tm = TimerMngt::getTimerMngt();
		this->nextTimer = tm->timerActiveListHead;
		tm->timerActiveListHead = this;
	}

	return 0;
}

Timer::~Timer()
{
	if(this->isRunning())
	  stopTimer();
}

int Timer::stopTimer(void)
{
	TimerMngt * tm = TimerMngt::getTimerMngt();
	Timer * iter = tm->timerActiveListHead;

	if (iter == NULL)
		return (-1);

	if (iter == this)
	{
		tm->timerActiveListHead = iter->nextTimer;
		this->nextTimer = NULL;
		return (0);
	}

	while (iter->nextTimer != NULL)
	{
		if (iter->nextTimer == this)
		{
			iter->nextTimer = this->nextTimer;
			return (0);
		}
		iter = iter->nextTimer;
	}

	return (-1);
}

bool Timer::isRunning()
{
	if (this->countDown_ms)
		return true;
	return false;
}


