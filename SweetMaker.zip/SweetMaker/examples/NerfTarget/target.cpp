/*******************************************************************************
Target.cpp - Takes a FizzyMint and creates a Target.

Copyright(C) 2017 Howard James May

This program is free software : you can redistribute it and / or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.If not, see <http://www.gnu.org/licenses/>.

Contact me at sweet.maker@outlook.com

*******************************************************************************/

#include <Arduino.h>
#include "target.h"
#include "SigConnector.h"
#include "StaticGen.h"
#include "SigConnector.h"
#include "SigStopper.h"

using namespace SweetMaker;

Target::Target(FizzyMint * fizzy)
{
	fizzyMint = fizzy;
	fizzyMint->configEventHandlerCallback(this);
}

void Target::setup()
{
	Serial.begin(115200);
	Serial.println(F("SweetMaker::FizzyMint Nerf Gun Target Example Sketch"));
}

/* 
 * 
 */
void Target::waitForNewGame()
{   
	fizzyMint->buzzer.playPeriod_us(NOTE_C5_US, 500);
	fizzyMint->updateDelay(500);

	Timer beepTimer, restartTimer;
	SigGen sineWave[3];
	for (int i = 0; i < 3; i++)	{
		sineWave[i].configSamples(sineWave255, NUM_SAM(sineWave255), 300, 0);
		sineWave[i].configOutput(&fizzyMint->light[i]);
	}

	switchPressedEvent = false;
	while (switchPressedEvent == false) {
		if (!restartTimer.isRunning()) {
			for (int i = 0; i < 3; i++) {
				sineWave[i].start(1, i * 200);
				restartTimer.startTimer(2000, 0);
				beepTimer.startTimer(600, 1);
				timer1Expired = false;
			}
		}

		if (timer1Expired == true)
		{
			fizzyMint->buzzer.playPeriod_us(NOTE_C6_US, 250);
			timer1Expired = false;
		}

		fizzyMint->update();
	}

	for (int i = 0; i < 3; i++) {
		sineWave[i].start(2);
	}

	fizzyMint->buzzer.playPeriod_us(NOTE_C7_US, 150);
	fizzyMint->updateDelay(200);
	fizzyMint->buzzer.playPeriod_us(NOTE_C7_US, 150);
	fizzyMint->updateDelay(200);

}

void Target::playStartTune()
{
	NOTE simpleMelody[] = {
		{ NOTE_C3_US,1 },
		{ NOTE_D3_US,1 },
		{ NOTE_E3_US,2 },

		{ NOTE_D3_US,1 },
		{ NOTE_E3_US,1 },
		{ NOTE_F3_US,2 },

		{ NOTE_E3_US,1 },
		{ NOTE_F3_US,1 },
		{ NOTE_G3_US,2 },

		{ NOTE_F3_US,1 },
		{ NOTE_G3_US,1 },
		{ NOTE_A3_US,2 },

		{ NOTE_G3_US,1 },
		{ NOTE_A3_US,1 },
		{ NOTE_B3_US,2 },

		{ NOTE_A3_US,1 },
		{ NOTE_B3_US,1 },
		{ NOTE_C4_US,2 }
	};
	fizzyMint->tunePlayer.playTune(simpleMelody, NUM_NOTE(simpleMelody), 1200);
	while (fizzyMint->tunePlayer.isRunning())
		fizzyMint->update();
}

void Target::startCountDown()
{
	u16 countdownNote_us = NOTE_A4_US;
	SigGen sineWave(sineWave255, NUM_SAM(sineWave255), 300, 0); 
	SigConnector sigCon[3];

	for (int i = 0; i < 3; i++)
		sigCon[i].configPorts(&sineWave, &fizzyMint->light[i]);

	for (int i = 0; i < 5; i++) {
		fizzyMint->buzzer.playPeriod_us(countdownNote_us, 300);
		sineWave.start(1);
		fizzyMint->updateDelay(800);
		countdownNote_us = countdownNote_us * 7 >> 3;
	}

	static const SigGen::SAMPLE alarm[] PROGMEM = { NOTE_G7_US, NOTE_B7_US, NOTE_D7_US };
	SigGen alarmGen(alarm, NUM_SAM(alarm), 90, SigGen::INTERPOLATE_OFF);
	sineWave.configPeriod_ms(90);

	for (int i = 0; i < 3; i++) {
		alarmGen.start(6, &fizzyMint->buzzer);
		sineWave.start(6);
		while (alarmGen.isRunning())
			fizzyMint->update();

		fizzyMint->buzzer.stop();
		fizzyMint->updateDelay(300);
	}

}



void Target::gameOn()
{
	static uint8_t score = 0;

	SigGen sineWave[3];
	for (int i = 0; i < 3; i++) {
		sineWave[i].configSamples(sineWave255, NUM_SAM(sineWave255), 300, 0);
		sineWave[i].configOutput(&fizzyMint->light[i]);
	}

	Timer beepTimer(5000, 0);

	piezoHitEvent = false;
	switchPressedEvent = false;
	score = 0;
	Serial.println("Starting to keep score");
	while (score < 5) {

		if (!beepTimer.isRunning()) 
		{
			Serial.println(score);
			beepTimer.startTimer(5000, 0);
			fizzyMint->buzzer.playPeriod_us(NOTE_C7_US, 100);
			for (int i = 0; i < 3; i++) {
				sineWave[i].start(1, i * 200);
			}
		}

		if (piezoHitEvent == true)
		{
			score++;
			for (int i = 0; i < 3; i++) {
				sineWave[i].start(1);
			}
			fizzyMint->buzzer.playPeriod_us(NOTE_C7_US, 100);

			fizzyMint->updateDelay(300);
			piezoHitEvent = false;
		}

		if (switchPressedEvent == true)
		{
			score++;
			for (int i = 0; i < 3; i++) {
				sineWave[i].start(1);
			}
			fizzyMint->buzzer.playPeriod_us(NOTE_C7_US, 100);

			fizzyMint->updateDelay(300);
			switchPressedEvent = false;
		}

		fizzyMint->update();
	}
}


void Target::announceWin()
{
	static const SigGen::SAMPLE fwSam[] PROGMEM = { 0,40,45,50,55,60,65,70,75,80,100,255,255,255,255,255,255,255,255,255 };
	static const SigGen::SAMPLE samStaticDuty[] PROGMEM = { 20,20,20,20,20,20,20,20,20,20,20,20,50,80,110,140,170,200,230,255 };
	static const SigGen::SAMPLE whizz[] PROGMEM = { NOTE_G7_US, NOTE_G5_US,NOTE_G4_US, NOTE_G3_US };
	static const SigGen::SAMPLE crackle[] PROGMEM = { NOTE_G6_US, NOTE_G4_US,NOTE_G5_US, NOTE_G3_US };
	SigGen sigGen[3];
	SigGen sigGenStaticDuty[3];
	StaticGen staticGen[3];
	SigStopper stopper[3];
	SigGen whizzSig(whizz, NUM_SAM(whizz), 2000, SigGen::DONT_LOOP);
	whizzSig.configEventRef(10);
	SigGen crackleSig(crackle, NUM_SAM(crackle), 200, SigGen::INTERPOLATE_OFF);

	for (int i = 0; i < 3; i++) {
		sigGen[i].configSamples(fwSam, NUM_SAM(fwSam), 4000, SigGen::DONT_LOOP);
		sigGen[i].configOutput(&stopper[i]);
		stopper[i].configOutput(&fizzyMint->light[i]);
		staticGen[i].configOutput(stopper[i].stopCtrl);
		staticGen[i].configPeriod_ms(20);
		staticGen[i].configDuty_256(230);

		sigGenStaticDuty[i].configSamples(samStaticDuty, NUM_SAM(samStaticDuty), 4000, SigGen::DONT_LOOP);
	}

	Timer timer[3];
	Timer finishTimer(15000, 0xffff);
	for (int i = 0; i < 3; i++) {
		timer[i].startTimer(random(0, 2000), 0xffff);
	}

	whizzSigFinished = false;
	while (finishTimer.isRunning()) {
		for (int i = 0; i < 3; i++) {
			staticGen[i].configDuty_256((uint8_t)sigGenStaticDuty[i].readValue());

			if (!timer[i].isRunning()) {
				sigGen[i].start(1);
				sigGenStaticDuty[i].start(1);
				timer[i].startTimer(random(3000, 5000), 0xffff);
				whizzSig.start(1, &fizzyMint->buzzer);
				crackleSig.stop();
			}
		}

		if (whizzSigFinished == true) {
			crackleSig.start(10, &fizzyMint->buzzer);
			whizzSigFinished = false;
		}

		fizzyMint->update();
	}
}

void Target::testing()
{
//		fizzyMint->buzzer.playPeriod_us(NOTE_C5_US, 500);
		while (1)
		{
			if (switchPressedEvent == true) {
//				fizzyMint->buzzer.playPeriod_us(NOTE_C5_US, 500);
				Serial.println("Switch Pressed");
				switchPressedEvent = false;
			}
			if (piezoHitEvent == true) {
				fizzyMint->light[0].turnOn();
				fizzyMint->updateDelay(1000);
				fizzyMint->light[0].turnOff();
				piezoHitEvent = false;
			}

			fizzyMint->update();
		}
}

void Target::loop()
{
//  testing();
	waitForNewGame();
	playStartTune();
	fizzyMint->updateDelay(1000);
	startCountDown();
	gameOn();
	announceWin();
}

void SweetMaker::Target::handleEvent(uint16_t eventId, uint8_t sourceReference, uint16_t eventInfo)
{
//	Serial.println(eventId);
	switch (eventId) {

		case SwitchDriver::SWITCH_TURNED_ON:
		switchPressedEvent = true;
		break;

		case SwitchDriver::SWITCH_HELD_ON:
		{
			switchHeldEvent = true;
			void(*resetFunc)(void) = 0;
			resetFunc();
		}

		break;

		case PiezoDriver::KNOCK_DETECTED:
		Serial.println("knock detected");
		piezoHitEvent = true;
		break;

		case TimerMngt::TIMER_EXPIRED:
		if (eventInfo == 0)
			timer0Expired = true;
		if (eventInfo == 1)
			timer1Expired = true;
		break;

		case SigGen::SIG_GEN_FINISHED:
		if (eventInfo == 10)
			whizzSigFinished = true;
		break;
	}
}
